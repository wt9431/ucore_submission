#ifndef __KERN_MM_PMM_H__
#define __KERN_MM_PMM_H__

void pmm_init(void);

#endif /* !__KERN_MM_PMM_H__ */

